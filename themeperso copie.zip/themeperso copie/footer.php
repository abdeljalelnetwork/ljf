<footer>
    <!-- Contenu du pied de page -->
    <footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4>Contactez-nous</h4>
                <p>123 Rue Principale, Ville</p>
                <p>Email : info@example.com</p>
                <p>Téléphone : +1234567890</p>
            </div>
            <div class="col-md-6">
                <h4>Suivez-nous</h4>
                <ul class="social-icons">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

</footer>
<?php wp_footer(); ?>
</body>
</html>
