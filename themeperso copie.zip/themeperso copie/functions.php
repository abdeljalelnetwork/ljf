<?php
// Ajoute la prise en charge des images mises en avant
add_theme_support('post-thumbnails');
