<?php get_header(); ?>

<!-- Contenu de la page d'article -->

<?php get_footer(); ?>
